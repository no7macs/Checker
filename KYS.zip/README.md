# Checker
 chekcs files against archived version of program and replaces missing ines
